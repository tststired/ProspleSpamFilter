# ProspleSpamFilter
cd git dir

zip -r a.zip .

about:debugging -> load temporary addon

~ key to filter out search, need to find an automatic solution after clicking next page but lazy